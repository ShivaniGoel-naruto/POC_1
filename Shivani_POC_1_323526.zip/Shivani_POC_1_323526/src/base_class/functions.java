package base_class;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utility.read_write;

public class functions extends read_write
{
static WebDriver dr;
static WebDriverWait wait;
static Logger log;
	public static void launchBrowser(String url)
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		dr=new ChromeDriver();
		dr.get(url);
	}

	public static void r_sex(String Gender) 
	{
		List<WebElement> rb=dr.findElements(By.name("Gender"));
		if(Gender=="Male")
			((WebElement) rb.get(0)).click();
		else
			((WebElement) rb.get(1)).click();
	}

	public void enter_text(String xp,String value) 
	{
		dr.findElement(By.xpath(xp)).sendKeys(value);
	}

	public void clickButton(String xp) 
	{
		dr.findElement(By.xpath(xp)).click();
	}

	public String verify(String xpath, String expected) 
	{
		String status;
		String actual = dr.findElement(By.xpath(xpath)).getText();
		if (actual.equals(expected)) 
			status = "PASS";
		else
			status = "FAIL";
		return status;
	}
	public int noofrows(String a) throws IOException
	{
		File f1=new File("Tc_condition.xlsx");
		FileInputStream fis=new FileInputStream(f1);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet(a);
		return(sh.getLastRowNum()+1);
	}
	public void waiting(String s)
	{
		wait=new WebDriverWait(dr,20);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(s)));
	}
	public void logging(String s)
	{
		log=Logger.getLogger("devpinoyLogger");
		log.info(s);
	}
}

